package com.busyqa.project.shoppingcart.service;


public class ShoppingCartBean {
}
