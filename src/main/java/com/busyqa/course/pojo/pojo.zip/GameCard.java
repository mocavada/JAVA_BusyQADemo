package com.busyqa.course.pojo;

public class GameCard {
    int id;
    int key;
    String rank;
    int number;


}
